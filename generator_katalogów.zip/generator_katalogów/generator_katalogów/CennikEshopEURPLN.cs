﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace generator_katalogów
{
    public partial class CennikEshopEURPLN : Form
    {
        public CennikEshopEURPLN()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (label11.Text == "")
            {
                MessageBox.Show(" *** Musisz być w stanie dostosować się do dynamicznych sytuacji! *** " + "\n" + "NIE WYBRANO PLIKU!" + "\n" + "OGARNIJ SIĘ!");
                return;
            }

            if (textBox3.Text == "")
            {
                MessageBox.Show(" *** Znoś ból dyscypliny albo znoś ból porażki! *** " + "\n" + "NIE NADAŁEŚ NAZWY PLIKU!" + "\n" + "OGARNIJ SIĘ!");
                return;
            }


            //----------------------------------------------------------------------------------------------------------------
            //  plik cenowy dla klienta z SAPa kanał 02
            //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
            //  |011030|200|||6,22|6,22|1|1||||

            //  plik cenowy dla klienta z SAPa kanał 01 lub 04
            //  773| 0|0050|29052020|31072020|9.0|07|EUR|

            string nrKatalogu = comboBox1.SelectedItem.ToString();
            string dataOd = textBox1.Text;
            string dataDo = textBox2.Text;
            string nrKlienta = textBox3.Text;
            string naglowek = "";
            string nrGrupy = textBox5.Text;
            string nrGVLa = textBox6.Text;
            string kurs = textBox4.Text;


            string waluta = "";


            if (radioButton4.Checked)
            {
                waluta = "EUR";
            }

            if (radioButton3.Checked)
            {
                waluta = "PLN";
            }


            string nazwaPliku = nrKlienta + ".dat";
            string sourcePath = label11.Text;

            if (radioButton1.Checked)
            {
                naglowek = nrKlienta + "|1|" + nrKatalogu + "|" + dataOd + "|" + dataDo + "|5.00|07|EUR||" + nrGrupy + "|X|||||||";
            }

            if (radioButton2.Checked)
            {
                naglowek = File.ReadLines(sourcePath).First();
                if (waluta == "PLN")
                {
                    naglowek = naglowek.Replace("|EUR|", "|PLN|");
                }
             }



            string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + nazwaPliku;

            // GENEROWANIE CENNIKA -------------------------------------------------------------------------------------------------------------------//

            // WARIANT Z KANAŁU 02 -------------------------------------------------------------------------------------------------------------------//
            cennikKanal02(sourcePath, targetPath, naglowek, nazwaPliku, kurs);
           
            // WARIANT Z KANAŁU 01/04 -------------------------------------------------------------------------------------------------------------------//
            cennikKanal04(sourcePath, targetPath, naglowek, nazwaPliku, kurs);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CennikEshopPLN_Activated(object sender, EventArgs e)
        {
            instrukcja();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.Visible = false;
            label10.Visible = false;

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.Visible = true;
            label10.Visible = true;
            textBox4.Text = "0,000";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {
                string fileName = openFileDialog1.FileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);

                // ROZPOZNANIE RODZAJU PLIKU POPRZEZ WCZYTANIE NAGŁÓWKA
                string naglowek = File.ReadLines(pathOfFile).First();

                int count = 0;
                char charToCount = '|';
                foreach (char c in naglowek)
                {
                    if (c == charToCount)
                    {
                        count++;
                    }
                }

                if (count > 10)
                {
                    radioButton2.Checked = true;
                }

                if (count < 10)
                {
                    radioButton1.Checked = true;
                }

                this.label9.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                pathOfFile = pathOfFile.Replace("\\", "\\\\");
                this.label11.Text = pathOfFile;
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            string kurs = textBox4.Text;
            double number;

            if (!Double.TryParse(kurs, out number))

            {
                MessageBox.Show("Sprawdź format kursu! - To celna uwaga! Zaparkuj ten temat!");
                return;
            }
        }

        private void instrukcja()
        {
            string tekst = "OPCJA GENEROWANIA PLIKU CENOWEGO" + Environment.NewLine +
            Environment.NewLine + "1. wybierz plik *dat wygenerowany z SAPa" +
            Environment.NewLine + "2. wybierz rodzaj kanału dystrybucji/ plik z 01 czy 02" +
            Environment.NewLine + "3. wybierz nr katalogu" +
            Environment.NewLine + "4. wprowadź datę obowiązywania od ... do ..." +
            Environment.NewLine + "5. wprowadź nr klienta" +
            Environment.NewLine + "5. sprawdź gr rabatowa klienta" +
            Environment.NewLine + "7. wybierz walutę cennika oraz ew. kurs";


            label1.Text = tekst;
            comboBox1.SelectedIndex = 0;

            if (radioButton4.Checked)
            {
                textBox4.Visible = false;
                label10.Visible = false;
            }
        }

        private void cennikKanal02(string sourcePath, string targetPath, string naglowek, string nazwaPliku, string kurs)
        {
            if (radioButton2.Checked)
            {

                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP
                System.IO.File.Copy(sourcePath, targetPath, true);

                //USUNIĘCIE PIERWSZEGO WIERSZA
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));

                //WCZYTANIE PLIKU
                //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
                //  |011030|200|||6,22|6,22|1|1||||

                string[] linesBeforeConvertion = File.ReadAllLines(targetPath);
                List<string> linesConverted = new List<string>();
                int lineNumber = 1;
                int linesNumber = linesBeforeConvertion.Count();

                foreach (string line in linesBeforeConvertion)
                {
                    var split = line.Split('|');
                    string itemNumber = split[1];
                    string itemSize = split[2];
                    string itemPrice1 = split[5];
                    string itemPrice2 = split[6];
                    string itemAmount1 = split[7];
                    string itemAmount2 = split[8];

                    itemPrice1 = itemPrice1.Replace(".", "");
                    itemPrice2 = itemPrice2.Replace(".", "");

                    //PRZELICZENIE WG KURSU
                    if (radioButton3.Checked)
                    {
                        //itemPrice1= itemPrice1.Replace(",", ".");
                        //itemPrice2= itemPrice2.Replace(",", ".");
                        // kurs = kurs.Replace(",", ".");

                        //    MessageBox.Show(itemPrice1+ " " +itemPrice2+" " + kurs);
                        itemPrice1 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice1));
                        itemPrice2 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice2));

                        itemPrice1 = itemPrice1.Replace(".", ",");
                        itemPrice2 = itemPrice2.Replace(".", ",");



                    }
                    var lineAfterConvertion = "|" + itemNumber + "|" + itemSize + "|||" + itemPrice1 + "|" + itemPrice2 + "|" + itemAmount1 + "|" + itemAmount2 + "||||";

                    linesConverted.Add(lineAfterConvertion);
                    lineNumber = lineNumber + 1;
                    progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
                }

                string[] linesAfterConvertion = linesConverted.ToArray();
                File.WriteAllLines(targetPath, linesAfterConvertion);



                //PODMIANA NAGŁÓWKA
                var txtLines = File.ReadAllLines(targetPath).ToList();
                txtLines.Insert(0, naglowek);
                File.WriteAllLines(targetPath, txtLines);

                //USUNIĘCIE PUSTYCH WIERSZY
                var lines = File.ReadAllLines(targetPath).Where(arg => !string.IsNullOrWhiteSpace(arg));
                File.WriteAllLines(targetPath, lines);

                //UTWORZENIE PLIKU NA PULPICIE
                System.IO.File.Copy(targetPath, Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + nazwaPliku, true);
                //USUNIĘCIE Z FOLDERU TEMP
                File.Delete(targetPath);

                MessageBox.Show("KONIEC - plik zapisano na pulpicie. Przetworzono linii: " + (linesNumber - 1).ToString());


                }
        }

        private void cennikKanal04(string sourcePath, string targetPath, string naglowek, string nazwaPliku, string kurs)
        {

            if (radioButton1.Checked)
            {

                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP
                System.IO.File.Copy(sourcePath, targetPath, true);
                //USUNIĘCIE PIERWSZEGO WIERSZA
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));

                //WCZYTANIE PLIKU

                //----------------------------------------------------------------------------------------------------------------
                //  plik cenowy dla klienta z SAPa kanał 02
                //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
                //  |011030|200|||6,22|6,22|1|1||||

                //  plik cenowy dla klienta z SAPa kanał 01 lub 04
                //  773| 0|0050|29052020|31072020|9.0|07|EUR|
                // | 011050 | 200 | Kalibracja DAkkS suwmiarek/ głęb.- mierzy | 9,80 |||||||||||

                string[] linesBeforeConvertion = File.ReadAllLines(targetPath);
                List<string> linesConverted = new List<string>();


                int lineNumber = 1;
                int linesNumber = linesBeforeConvertion.Count();

                foreach (string line in linesBeforeConvertion)
                {
                    var split = line.Split('|');
                    string itemNumber = split[1];
                    string itemSize = split[2];
                    string itemPrice1 = split[4];
                    string itemPrice2 = split[5];
                    string itemAmount1 = split[6];
                    string itemAmount2 = "";


                    itemPrice1 = itemPrice1.Trim();
                    itemPrice2 = itemPrice2.Trim();
                    itemPrice1 = itemPrice1.Replace(".", "");
                    itemPrice2 = itemPrice2.Replace(".", "");

                    if (string.IsNullOrEmpty(itemPrice1))
                    {
                        itemPrice1 = "0,00";
                    }

                    if (string.IsNullOrEmpty(itemPrice2))
                    {
                        itemPrice2 = itemPrice1;
                    }

                    if (string.IsNullOrEmpty(itemAmount1))
                    {
                        itemAmount1 = "1";
                        itemAmount2 = "1";
                    }

                    if (itemAmount1 != "")
                    {
                        itemAmount1 = itemAmount1.Trim();
                        itemAmount2 = itemAmount1;
                        itemAmount1 = "1";
                    }

                    //   itemPrice1 = itemPrice1.Replace(".", "");
                    //     itemPrice2 = itemPrice2.Replace(".", "");

                    //PRZELICZENIE WG KURSU
                    if (radioButton3.Checked)
                    {

                        //itemPrice1 =itemPrice1.Replace(",", ".");
                        //itemPrice2 = itemPrice2.Replace(",", ".");
                        // kurs = kurs.Replace(",", ".");



                        try
                        {
                            itemPrice1 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice1));
                            itemPrice2 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice2));
                        }

                        catch
                        {
                            MessageBox.Show("błąd w linii: " + itemPrice1 + " " + itemPrice2 + " " + kurs);
                        }

                        itemPrice1 = itemPrice1.Replace(".", ",");
                        itemPrice2 = itemPrice2.Replace(".", ",");

                    }

                    var lineAfterConvertion = "|" + itemNumber + "|" + itemSize + "|||" + itemPrice1 + "|" + itemPrice2 + "|" + itemAmount1 + "|" + itemAmount2 + "||||";
                    linesConverted.Add(lineAfterConvertion);

                    lineNumber = lineNumber + 1;
                    progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
                }

                string[] linesAfterConvertion = linesConverted.ToArray();
                File.WriteAllLines(targetPath, linesAfterConvertion);

                //DODANIE NAGŁÓWKA
                var txtLines = File.ReadAllLines(targetPath).ToList();
                txtLines.Insert(0, naglowek);
                File.WriteAllLines(targetPath, txtLines);

                //USUNIĘCIE PUSTYCH WIERSZY
                var lines = File.ReadAllLines(targetPath).Where(arg => !string.IsNullOrWhiteSpace(arg));
                File.WriteAllLines(targetPath, lines);

                //UTWORZENIE PLIKU NA PULPICIE
                System.IO.File.Copy(targetPath, Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + nazwaPliku, true);
                //USUNIĘCIE Z FOLDERU TEMP
                File.Delete(targetPath);

                MessageBox.Show("KONIEC - plik zapisano na pulpicie. Przetworzono linii: " + (linesNumber - 1).ToString());


            }
        }
    }
}
