﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace generator_katalogów
{
    public partial class XML_tool : Form
    {
        public XML_tool()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {


                string fileName = openFileDialog1.FileName;
                string onlyFileName = openFileDialog1.SafeFileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);
                string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + onlyFileName;



                fileName = fileName.Replace("\\", "\\\\");

                //----------------------------------------------------------------------------------
                // WCZYTANIE ZAWARTOŚCI PLIKU
                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP


                System.IO.File.Copy(fileName, targetPath, true);


                targetPath = targetPath.Replace("\\", "\\\\");

                //this.label9.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                this.label11.Text = targetPath;



            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] fileConverting = File.ReadAllLines(label11.Text);
            List<string> linesConverted = new List<string>();


            string searchedText = textBox1.Text;



            int lineNumber = 1;
            int linesNumber = fileConverting.Count();
            progressBar1.Value = 0;



            foreach (string line in fileConverting)
            {
                if (!line.Contains(searchedText))

                {

                    linesConverted.Add(line);
                    progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
                }

                lineNumber++;
                label2.Text = progressBar1.Value.ToString() + "%";
            }


            File.WriteAllLines(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + "NEW_XML.xml", linesConverted);
            MessageBox.Show("ok");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}