﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace generator_katalogów
{
    public partial class CSV_do_XMLa_BMEcat : Form
    {
        public CSV_do_XMLa_BMEcat()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CSV_do_XMLa_BMEcat_Activated(object sender, EventArgs e)
        {
            instrukcja();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {
                string fileName = openFileDialog1.FileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);

                // ROZPOZNANIE RODZAJU PLIKU POPRZEZ WCYZTANIE NAGŁÓWKA
                string naglowek = File.ReadLines(pathOfFile).First();

                int count = 0;
                char charToCount = '|';
                foreach (char c in naglowek)
                {
                    if (c == charToCount)
                    {
                        count++;
                    }
                }

                if (count > 10)
                {
                    radioButton2.Checked = true;
                }

                if (count < 10)
                {
                    radioButton1.Checked = true;
                }
                this.label9.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                pathOfFile = pathOfFile.Replace("\\", "\\\\");
                this.label2.Text = pathOfFile;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {

            if (label2.Text == "")
            {
                MessageBox.Show(" *** Musisz być w stanie dostosować się do dynamicznych sytuacji! *** " + "\n" + "NIE WYBRANO PLIKU!" + "\n" + "OGARNIJ SIĘ!");
                return;
            }

            if (textBox3.Text == "")
            {
                MessageBox.Show(" *** Znoś ból dyscypliny albo znoś ból porażki! *** " + "\n" + "NIE NADAŁEŚ NAZWY PLIKU!" + "\n" + "OGARNIJ SIĘ!");
                return;
            }


            string dataOd = textBox1.Text;
            string dataDo = textBox2.Text;
            string naglowek = "supplierAID;priceAmount1;priceTyp1;lowerBound1;tax1;currency1;priceAmount2; priceTyp2; lowerBound2;tax2;currency2; dateTime1;dateTime2";
            string nazwaPliku = textBox3.Text + ".csv";
            string sourcePath = label2.Text;
            string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + nazwaPliku;
            string waluta="";
            string kurs = textBox4.Text;

            if (radioButton4.Checked)
            {
                waluta = "EUR";
            }

            if (radioButton3.Checked)
            {
                waluta = "PLN";
            }



            if (radioButton1.Checked)
            {
                // WARIANT Z KANAŁU 01/04 -------------------------------------------------------------------------------------------------------------------//
                cennikKanal04(sourcePath, targetPath, naglowek, nazwaPliku, kurs, waluta, dataOd, dataDo);
            }


            // WARIANT Z KANAŁU 02 ----------------------------------------------------------------------------------------------------------------------//
            //TEGO NIE ROBIMY//
            if (radioButton2.Checked)
            {
                // WARIANT Z KANAŁU 01/04 -------------------------------------------------------------------------------------------------------------------//
                cennikKanal02(sourcePath, targetPath, naglowek, nazwaPliku, kurs, waluta, dataOd, dataDo);
            }


        }

        private void instrukcja()
        {
            string tekst = "OPCJA GENEROWANIA PLIKU CSV DO TWORZENIA KATALOGU W XML-U" + Environment.NewLine +
           Environment.NewLine + "1. wybierz plik *dat wygenerowany z SAPa" +
           Environment.NewLine + "2. kanału dystrybucji/ plik z 01 czy 02 ( system rozpozna automatycznie po wczytaniu nagłówka pliku )" +
           Environment.NewLine + "3. wczytanie waluty ( automatycznie)" +
           Environment.NewLine + "4. wprowadź datę obowiązywania od ... do ..." +
           Environment.NewLine + "5. wprowadź nazwę pliku";
            label1.Text = tekst;
            textBox4.Visible = false;
            label10.Visible = false;
        }

        private void cennikKanal04(string sourcePath, string targetPath, string naglowek, string nazwaPliku, string kurs, string waluta, string dataOd, string dataDo)
        {

            if (radioButton1.Checked)
            {

                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP
                System.IO.File.Copy(sourcePath, targetPath, true);
                //USUNIĘCIE PIERWSZEGO WIERSZA
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));

                //WCZYTANIE PLIKU

                //----------------------------------------------------------------------------------------------------------------
                //  plik cenowy dla klienta z SAPa kanał 02
                //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
                //  |011030|200|||6,22|6,22|1|1||||

                //  plik cenowy dla klienta z SAPa kanał 01 lub 04
                //  773| 0|0050|29052020|31072020|9.0|07|EUR|
                // | 011050 | 200 | Kalibracja DAkkS suwmiarek/ głęb.- mierzy | 9,80 |||||||||||

                string[] linesBeforeConvertion = File.ReadAllLines(targetPath);
                List<string> linesConverted = new List<string>();


                int lineNumber = 1;
                int linesNumber = linesBeforeConvertion.Count();

                foreach (string line in linesBeforeConvertion)
                {

                    var split = line.Split('|');
                    string itemNumber = split[1];
                    string itemSize = split[2];
                    string itemPrice1 = split[4];
                    string itemPrice2 = split[5];
                    string itemAmount1 = split[6];
                    string itemAmount2 = "";

                  
                    itemPrice1 = itemPrice1.Trim();
                    itemPrice2 = itemPrice2.Trim();
                    itemPrice1 = itemPrice1.Replace(".", "");
                    itemPrice2 = itemPrice2.Replace(".", "");

                    if (string.IsNullOrEmpty(itemPrice1))
                    {
                        itemPrice1 = "0,00";
                    }

                    // BRAK DRUGIEJ CENY
                    //  if (string.IsNullOrEmpty(itemPrice2))
                    //{
                      //  itemPrice2 = "0";
                    //}

                  // BRAK DRUGIEJ CENY
                    if (string.IsNullOrEmpty(itemAmount1))
                   {
                     itemAmount1 = "1";
                     itemAmount2 = "0";
                    }

                    if (itemAmount1 != "")
                    {
                        itemAmount1 = itemAmount1.Trim();
                        itemAmount2 = itemAmount1;
                        itemAmount1 = "1";
                    }



                    //PRZELICZENIE WG KURSU
                    if (radioButton3.Checked)
                    {
                        try
                        {
                            itemPrice1 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice1));
                            if (!string.IsNullOrEmpty(itemPrice2))
                            {
                                itemPrice2 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice2));
                            }
                            }

                        catch
                        {
                            MessageBox.Show("błąd w linii: " +itemNumber+ " " + itemSize+ " " + itemPrice1 + " " + itemPrice2 + " " + kurs);
                        }

                        itemPrice1 = itemPrice1.Replace(".", ",");
                        itemPrice2 = itemPrice2.Replace(".", ",");

                    }

                    string line1 = "";

                    //SPRAWDZENIE CZY PRODUKT MA ROZMIAR

                    if (string.IsNullOrEmpty(itemSize))
                    {
                       line1 = itemNumber  + ";" + itemPrice1 + ";" + "net_customer" + ";" + itemAmount1 + ";" + "0.23" + ";" + waluta;
                    }

                    if (!string.IsNullOrEmpty(itemSize))
                    {
                        line1 = itemNumber + " " + itemSize + ";" + itemPrice1 + ";" + "net_customer" + ";" + itemAmount1 + ";" + "0.23" + ";" + waluta;
                    }

                    string line2 = ";" + itemPrice2 + ";" + "net_customer" + ";" + itemAmount2 + ";" + "0.23" + ";" + waluta;

                    string line3 = ";" + dataOd + ";" + dataDo;

                    string fullLine="";

                    //SPRAWDZENIE CZY PRODUKT MA DRUGĄ CENĘ

                    if (string.IsNullOrEmpty(itemPrice2))
                    {
                        fullLine = line1+ ";" + ";" + ";" + ";" + ";" + line3;
                    }

                    if (!string.IsNullOrEmpty(itemPrice2))
                    {
                        fullLine = line1 + line2 + line3;
                    }

                    var lineAfterConvertion = fullLine;

                    linesConverted.Add(lineAfterConvertion);

                    lineNumber = lineNumber + 1;
                    progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
                }

                string[] linesAfterConvertion = linesConverted.ToArray();
                File.WriteAllLines(targetPath, linesAfterConvertion);

                //DODANIE NAGŁÓWKA
                var txtLines = File.ReadAllLines(targetPath).ToList();
                txtLines.Insert(0, naglowek);
                File.WriteAllLines(targetPath, txtLines);

                //USUNIĘCIE PUSTYCH WIERSZY
                var lines = File.ReadAllLines(targetPath).Where(arg => !string.IsNullOrWhiteSpace(arg));
                File.WriteAllLines(targetPath, lines);

                //UTWORZENIE PLIKU NA PULPICIE
                System.IO.File.Copy(targetPath, Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + nazwaPliku, true);
                //USUNIĘCIE Z FOLDERU TEMP
                File.Delete(targetPath);

                MessageBox.Show("KONIEC - plik zapisano na pulpicie. Przetworzono linii: " + (linesNumber - 1).ToString());


            }
        }


        private void cennikKanal02(string sourcePath, string targetPath, string naglowek, string nazwaPliku, string kurs, string waluta, string dataOd, string dataDo)
        {

            if (radioButton2.Checked)
            {

                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP
                System.IO.File.Copy(sourcePath, targetPath, true);
                //USUNIĘCIE PIERWSZEGO WIERSZA
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));

                //WCZYTANIE PLIKU

                //----------------------------------------------------------------------------------------------------------------
                //  plik cenowy dla klienta z SAPa kanał 02
                //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
                //  |011030|200|||6,22|6,22|1|1||||

                //  plik cenowy dla klienta z SAPa kanał 01 lub 04
                //  773| 0|0050|29052020|31072020|9.0|07|EUR|
                // | 011050 | 200 | Kalibracja DAkkS suwmiarek/ głęb.- mierzy | 9,80 |||||||||||

                string[] linesBeforeConvertion = File.ReadAllLines(targetPath);
                List<string> linesConverted = new List<string>();


                int lineNumber = 1;
                int linesNumber = linesBeforeConvertion.Count();

                foreach (string line in linesBeforeConvertion)
                {

                    var split = line.Split('|');
                    string itemNumber = split[1];
                    string itemSize = split[2];
                    string itemPrice1 = split[5];
                    string itemPrice2 = split[6];
                    string itemAmount1 = split[7];
                    string itemAmount2 = split[8];


                    itemPrice1 = itemPrice1.Trim();
                    itemPrice2 = itemPrice2.Trim();
                    itemPrice1 = itemPrice1.Replace(".", "");
                    itemPrice2 = itemPrice2.Replace(".", "");

                    if (string.IsNullOrEmpty(itemPrice1))
                    {
                        itemPrice1 = "0,00";
                    }

        
                    // BRAK DRUGIEJ CENY
                    if (string.IsNullOrEmpty(itemAmount1))
                    {
                        itemAmount1 = "1";
                        itemAmount2 = "0";
                    }

                    if (itemAmount1 != "")
                    {
                        itemAmount1 = itemAmount1.Trim();

                    }

                    if (itemAmount2 != "")
                    {
                        itemAmount2 = itemAmount2.Trim();

                    }



                    //PRZELICZENIE WG KURSU
                    if (radioButton3.Checked)
                    {
                        try
                        {
                            itemPrice1 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice1));
                            if (!string.IsNullOrEmpty(itemPrice2))
                            {
                                itemPrice2 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice2));
                            }
                        }

                        catch
                        {
                            MessageBox.Show("błąd w linii: " + itemNumber + " " + itemSize + " " + itemPrice1 + " " + itemPrice2 + " " + kurs);
                        }

                        itemPrice1 = itemPrice1.Replace(".", ",");
                        itemPrice2 = itemPrice2.Replace(".", ",");

                    }

                    string line1 = "";

                    //SPRAWDZENIE CZY PRODUKT MA ROZMIAR

                    if (string.IsNullOrEmpty(itemSize))
                    {
                        line1 = itemNumber + ";" + itemPrice1 + ";" + "net_customer" + ";" + itemAmount1 + ";" + "0.23" + ";" + waluta;
                    }

                    if (!string.IsNullOrEmpty(itemSize))
                    {
                        line1 = itemNumber + " " + itemSize + ";" + itemPrice1 + ";" + "net_customer" + ";" + itemAmount1 + ";" + "0.23" + ";" + waluta;
                    }

                    string line2 = ";" + itemPrice2 + ";" + "net_customer" + ";" + itemAmount2 + ";" + "0.23" + ";" + waluta;

                    string line3 = ";" + dataOd + ";" + dataDo;

                    string fullLine = "";

                    //SPRAWDZENIE CZY PRODUKT MA DRUGĄ CENĘ

                    if (string.IsNullOrEmpty(itemPrice2))
                    {
                        fullLine = line1 + ";" +  ";"  + ";" +";" + ";" + line3;
                    }

                    if (!string.IsNullOrEmpty(itemPrice2))
                    {
                        if (string.Equals(itemPrice1, itemPrice2))
                        {
                            fullLine = line1+";" + ";" + ";" + ";" + ";" + line3;

                        }

                        else
                        {
                            fullLine = line1 + line2 + line3;
                        }
                        }

                    var lineAfterConvertion = fullLine;

                    linesConverted.Add(lineAfterConvertion);

                    lineNumber = lineNumber + 1;
                    progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
                }

                string[] linesAfterConvertion = linesConverted.ToArray();
                File.WriteAllLines(targetPath, linesAfterConvertion);

                //DODANIE NAGŁÓWKA
                var txtLines = File.ReadAllLines(targetPath).ToList();
                txtLines.Insert(0, naglowek);
                File.WriteAllLines(targetPath, txtLines);

                //USUNIĘCIE PUSTYCH WIERSZY
                var lines = File.ReadAllLines(targetPath).Where(arg => !string.IsNullOrWhiteSpace(arg));
                File.WriteAllLines(targetPath, lines);

                //UTWORZENIE PLIKU NA PULPICIE
                System.IO.File.Copy(targetPath, Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + nazwaPliku, true);
                //USUNIĘCIE Z FOLDERU TEMP
                File.Delete(targetPath);

                MessageBox.Show("KONIEC - plik zapisano na pulpicie. Przetworzono linii: " + (linesNumber - 1).ToString());


            }
        }



        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.Visible = false;
            label10.Visible = false;
            textBox4.Text = "0,000";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.Visible = true;
            label10.Visible = true;
            textBox4.Text = "0,000";
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            string kurs = textBox4.Text;
            double number;

            if (!Double.TryParse(kurs, out number))

            {
                MessageBox.Show("Sprawdź format kursu! - To celna uwaga! Zaparkuj ten temat!");
                return;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

