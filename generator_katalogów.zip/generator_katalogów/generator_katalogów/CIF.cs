﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;

namespace generator_katalogów
{
    public partial class CIF : Form
    {

  
        public CIF()
        {
            InitializeComponent();
 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {

                
                string fileName = openFileDialog1.FileName;
                string onlyFileName = openFileDialog1.SafeFileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);
                string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + onlyFileName;
                //----------------------------------------------------------------------------------
                // WCZYTANIE NAGŁÓWKA
                string naglowek = File.ReadLines(fileName).First();

                //PODZIAŁ - WYSZUKIWANIE KOLUMN
                string[] parts = naglowek.Split(';');

                treeView1.Nodes.Add(onlyFileName);
                fileName = fileName.Replace("\\", "\\\\");
                treeView2.Nodes.Add(targetPath);
                foreach (string part in parts)
                {
                    //dodanie do treeView
                    treeView1.Nodes[treeView1.Nodes.Count - 1].Nodes.Add(part.ToUpper());
                    treeView2.Nodes[treeView1.Nodes.Count - 1].Nodes.Add(part);
                }

                //----------------------------------------------------------------------------------
                // WCZYTANIE ZAWARTOŚCI PLIKU
                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP

      
                System.IO.File.Copy(fileName, targetPath, true);

                //USUNIĘCIE PIERWSZEGO WIERSZA I ZAPISANIE KOPII PLIKÓW ŹRÓDŁOWYCH
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));


                this.label9.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                this.label11.Text = pathOfFile;
                this.label2.Text = "liczba wierszy do przetworzenia: ";


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            treeView1.Nodes.Clear();
            treeView2.Nodes.Clear();
            label1.Text = "brak plików";
            label2.Text = "liczba wierszy do przetworzenia: ";
            checkedListBox1.Items.Clear();
   

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
      


        }
     

        private void CIF_Activated(object sender, EventArgs e)
        {
     
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\CIF_temp.cif";
            createCIF(treeView2.Nodes[0].Text, treeView2.Nodes[1].Text, targetPath);
            MessageBox.Show("KONIEC");
        }

        private void CIF_Load(object sender, EventArgs e)
        {
            // TYMCZASOWY PLIK CIF W TEMP
            string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\CIF_temp.cif";

     
            if (File.Exists(targetPath))
            {
               // File.Delete(targetPath);
            }
             //System.IO.File.Create(targetPath);

        }


        private void createCIF(string filePath1, string filePath2, string targetPath)

        {
          

            string[] file1 = System.IO.File.ReadAllLines(filePath1);
            string[] file2 = System.IO.File.ReadAllLines(filePath2);
            List<string> linesConverted = new List<string>();

            IEnumerable<string> Query1 =
            from fields1 in file1
            let fieldsFile1 = fields1.Split(';')
            from fields2 in file2
            let fieldsFile2 = fields2.Split(';')
            where fieldsFile1[0] == fieldsFile2[0]
            select fields1 +";" + fields2;

            int lineNumber = 1;
            int linesNumber = Query1.Count();


            foreach (string item in Query1)
            {
                linesConverted.Add(item);
                lineNumber = lineNumber + 1;
                progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
            }


            string[] linesAfterConvertion = linesConverted.ToArray();
            File.WriteAllLines(targetPath, linesAfterConvertion);

            
        }
    }
}
