﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace generator_katalogów
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            string tekst = "OPCJA GENEROWANIA PLIKU RABATTSTUFFEN DO ESHOPA" + Environment.NewLine +
        Environment.NewLine + "na podstawie pliku *dat wygenerowanego z SAPa z kanału 01 lub 02.";
            label2.Text = tekst;
            podswietlOpcje();

        }


        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            string tekst = "OPCJA GENEROWANIA CENNIKA DO ESHOPA" + Environment.NewLine +
            Environment.NewLine + "na podstawie pliku *dat wygenerowanego z SAPa z kanału 01 lub 02" +
            Environment.NewLine + "oraz z możliwością wyboru waluty: EUR lub PLN ( wraz z kursem).";
            label2.Text = tekst;
            podswietlOpcje();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                Rabattstuffen rs = new Rabattstuffen();
                rs.ShowDialog();
            }

            if (radioButton2.Checked)
            {
                CennikEshopEURPLN ce = new CennikEshopEURPLN();
                ce.ShowDialog();
            }

            if (radioButton3.Checked)
            {
                CIF cif= new CIF();
                cif.ShowDialog();
            }

            if (radioButton4.Checked)
            {
                CSV_do_XMLa_BMEcat csvXML = new CSV_do_XMLa_BMEcat();
                csvXML.ShowDialog();
            }

            if (radioButton5.Checked)
            {
                CSV_TO_ESHOP csvSshop = new CSV_TO_ESHOP();
                csvSshop.ShowDialog();
            }

            if (radioButton6.Checked)
            {
               mergeCSV mergeCSV = new mergeCSV();
                mergeCSV.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            var path = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp";


        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            string tekst = "OPCJA GENEROWANIA CENNIKA/PLIKU CSV DO KATALOGU XML" + Environment.NewLine +
          Environment.NewLine + "na podstawie pliku *dat wygenerowanego z SAPa z kanału 01 lub 02" +
          Environment.NewLine + "oraz z możliwością wyboru waluty: EUR lub PLN ( wraz z kursem).";
            label2.Text = tekst;
            podswietlOpcje();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            string tekst = "OPCJA GENEROWANIA CENNIKA DO ESHOPA" + Environment.NewLine +
          Environment.NewLine + "na podstawie pliku *CSV w układzie min. trzy-kolumnowym:" +
          Environment.NewLine + "artrykuł z rozmiarem/cena/dowolna" +
          Environment.NewLine + "oraz z możliwością wyboru waluty: EUR lub PLN ( wraz z kursem).";
            label2.Text = tekst;
            podswietlOpcje();
        }


        private void podswietlOpcje()
        {
            foreach (RadioButton RadioButton_X in groupBox1.Controls)
            {
                if (RadioButton_X.Checked == true)
                {

                    RadioButton_X.BackColor = Color.Yellow;


                }

                else
                {
                    RadioButton_X.BackColor = Color.Transparent;

                }
            }


        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            string tekst = "OPCJA GENEROWANIA PLIKU CIF" + Environment.NewLine +
             Environment.NewLine + "na podstawie plików *CSV o dowlnym  układzie ";
            label2.Text = tekst;
            podswietlOpcje();
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            XML_tool xmlTool = new XML_tool();
            xmlTool.ShowDialog();

        }
    } 
    }