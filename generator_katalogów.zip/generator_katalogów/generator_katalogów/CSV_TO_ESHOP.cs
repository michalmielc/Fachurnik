﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace generator_katalogów
{
    public partial class CSV_TO_ESHOP : Form
    {
        public CSV_TO_ESHOP()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void instrukcja()
        {
            string tekst = "OPCJA GENEROWANIA CENNKA DO ESHOPA Z CSV" + Environment.NewLine +
           Environment.NewLine + "0. przygotuj plik *csv " +
           Environment.NewLine + "  - usuń nagłówek" +
           Environment.NewLine + "  KOLUMNA A - nr artykułu z rozmiarem; KOLUMNA B cena; KOLUMNA C  dowolny znak ( musi być !)" +
            Environment.NewLine + "1. wybierz plik *csv " +
           Environment.NewLine + "2. wczytanie waluty ( automatycznie)" +
           Environment.NewLine + "3. wprowadź datę obowiązywania od ... do ..." +
           Environment.NewLine + "4. wprowadź nazwę pliku";
            label1.Text = tekst;
            textBox4.Visible = false;
            label10.Visible = false;
        }

        private void CSV_TO_ESHOP_Activated(object sender, EventArgs e)
        {
            instrukcja();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.Visible = false;
            label10.Visible = false;
            textBox4.Text = "0,000";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.Visible = true;
            label10.Visible = true;
            textBox4.Text = "0,000";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (label11.Text == "")
            {
                MessageBox.Show(" *** Musisz być w stanie dostosować się do dynamicznych sytuacji! *** " + "\n" + "NIE WYBRANO PLIKU!" + "\n" + "OGARNIJ SIĘ!");
                return;
            }

            if (textBox3.Text == "")
            {
                MessageBox.Show(" *** Znoś ból dyscypliny albo znoś ból porażki! *** " + "\n" + "NIE NADAŁEŚ NAZWY PLIKU!" + "\n" + "OGARNIJ SIĘ!");
                return;
            }


            //----------------------------------------------------------------------------------------------------------------
            //  plik cenowy dla klienta z SAPa kanał 02
            //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
            //  |011030|200|||6,22|6,22|1|1||||

            //  plik cenowy dla klienta z SAPa kanał 01 lub 04
            //  773| 0|0050|29052020|31072020|9.0|07|EUR|

            string nrKatalogu = comboBox1.SelectedItem.ToString();
            string dataOd = textBox1.Text;
            string dataDo = textBox2.Text;
            string nrKlienta = textBox3.Text;
            string naglowek = "";
            string nrGrupy = textBox5.Text;
            string nrGVLa = textBox6.Text;
            string kurs = textBox4.Text;


            string waluta = "";


            if (radioButton4.Checked)
            {
                waluta = "EUR";
            }

            if (radioButton3.Checked)
            {
                waluta = "PLN";
            }


            string nazwaPliku = nrKlienta + ".dat";
            string sourcePath = label11.Text;

            if (radioButton1.Checked)
            {
                naglowek = nrKlienta + "|1|" + nrKatalogu + "|" + dataOd + "|" + dataDo + "|5.00|07|EUR||" + nrGrupy + "|X|||||||";
            }

            if (radioButton2.Checked)
            {
                naglowek = File.ReadLines(sourcePath).First();
                if (waluta == "PLN")
                {
                    naglowek = naglowek.Replace("|EUR|", "|PLN|");
                }
            }

            string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + nazwaPliku;

            // TWORZENIE CENNIKA-------------------------------------------------------------------------------------------------------------------//
            tworzCennik(sourcePath, targetPath, naglowek, nazwaPliku, kurs);
        }


        private void tworzCennik(string sourcePath, string targetPath, string naglowek, string nazwaPliku, string kurs)
        {
        

                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP
                System.IO.File.Copy(sourcePath, targetPath,true);

                //USUNIĘCIE PIERWSZEGO WIERSZA
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));

                //WCZYTANIE PLIKU
                //  00773|1|K50|29052020|31072020|5.00|07|EUR||0000990490|7PLPLEUR|X|||||||
                //  |011030|200|||6,22|6,22|1|1||||

                string[] linesBeforeConvertion = File.ReadAllLines(targetPath);
                List<string> linesConverted = new List<string>();
                int lineNumber = 1;
                int linesNumber = linesBeforeConvertion.Count();

                foreach (string line in linesBeforeConvertion)
                {
                    var split = line.Split(';');
                    string itemNumberAndSize = split[0];
                    string itemPrice= split[1];
                    string itemSize = "";

            //     MessageBox.Show(itemNumberAndSize.Length.ToString());
                // PODMIANA WARTOŚCI
                    string itemNumber = itemNumberAndSize.Substring(0,6);

                    if (itemNumberAndSize.Length > 6)
                    {
                    itemSize = itemNumberAndSize.Substring(7,itemNumberAndSize.Length-7);
                    }

    
                    string itemPrice1 = itemPrice;
                    string itemPrice2 = itemPrice;
                    string itemAmount1 = "1";
                    string itemAmount2 = "1";

                    itemPrice1 = itemPrice1.Replace(".", "");
                    itemPrice2 = itemPrice2.Replace(".", "");

                    //PRZELICZENIE WG KURSU
                    if (radioButton3.Checked)
                    {

                 

                    try
                    {
                        itemPrice1 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice1));
                        itemPrice2 = string.Format("{0:0.00}", double.Parse(kurs) * double.Parse(itemPrice2));

                        itemPrice1 = itemPrice1.Replace(".", ",");
                        itemPrice2 = itemPrice2.Replace(".", ",");
                    }
                    catch
                    {
                        MessageBox.Show("NIEPRAWIDŁOWA LICZBA KOLUMN!");
                        return;

                    }


                }
                    var lineAfterConvertion = "|" + itemNumber + "|" + itemSize + "|||" + itemPrice1 + "|" + itemPrice2 + "|" + itemAmount1 + "|" + itemAmount2 + "||||";

                    linesConverted.Add(lineAfterConvertion);
                    lineNumber = lineNumber + 1;
                    progressBar1.Value = (int)(100 * (lineNumber / linesNumber));

            }
            string[] linesAfterConvertion = linesConverted.ToArray();
                File.WriteAllLines(targetPath, linesAfterConvertion);



                //PODMIANA NAGŁÓWKA
                var txtLines = File.ReadAllLines(targetPath).ToList();
                txtLines.Insert(0, naglowek);
                File.WriteAllLines(targetPath, txtLines);

                //USUNIĘCIE PUSTYCH WIERSZY
                var lines = File.ReadAllLines(targetPath).Where(arg => !string.IsNullOrWhiteSpace(arg));
                File.WriteAllLines(targetPath, lines);

                //UTWORZENIE PLIKU NA PULPICIE
                System.IO.File.Copy(targetPath, Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + nazwaPliku, true);
                //USUNIĘCIE Z FOLDERU TEMP
                File.Delete(targetPath);

                MessageBox.Show("KONIEC - plik zapisano na pulpicie. Przetworzono linii: " + (linesNumber - 1).ToString());


           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {
                string fileName = openFileDialog1.FileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);

                // ROZPOZNANIE RODZAJU PLIKU POPRZEZ WCZYTANIE NAGŁÓWKA
                string naglowek = File.ReadLines(pathOfFile).First();

                int count = 0;
                char charToCount = '|';
                foreach (char c in naglowek)
                {
                    if (c == charToCount)
                    {
                        count++;
                    }
                }

                if (count > 10)
                {
                    radioButton2.Checked = true;
                }

                if (count < 10)
                {
                    radioButton1.Checked = true;
                }

                this.label9.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                pathOfFile = pathOfFile.Replace("\\", "\\\\");
                this.label11.Text = pathOfFile;
            }
        }

     
    }
}
