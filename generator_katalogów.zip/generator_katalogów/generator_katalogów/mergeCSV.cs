﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Collections.Specialized;

namespace generator_katalogów
{
    public partial class mergeCSV : Form
    {


        public mergeCSV()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {

                
                string fileName = openFileDialog1.FileName;
                string onlyFileName = openFileDialog1.SafeFileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);
                string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + onlyFileName;
                //----------------------------------------------------------------------------------
                // WCZYTANIE NAGŁÓWKA
                string naglowek = File.ReadLines(fileName).First();

                //PODZIAŁ - WYSZUKIWANIE KOLUMN
                string[] parts = naglowek.Split(';');


                fileName = fileName.Replace("\\", "\\\\");

                //----------------------------------------------------------------------------------
                // WCZYTANIE ZAWARTOŚCI PLIKU
                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP


                System.IO.File.Copy(fileName, targetPath, true);

                //USUNIĘCIE PIERWSZEGO WIERSZA I ZAPISANIE KOPII PLIKÓW ŹRÓDŁOWYCH
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));

                targetPath = targetPath.Replace("\\", "\\\\");

                this.label9.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                this.label11.Text = targetPath;
                this.label2.Text = "liczba wierszy do przetworzenia: ";


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {
                string fileName = openFileDialog1.FileName;
                string onlyFileName = openFileDialog1.SafeFileName;
                string pathOfFile = System.IO.Path.GetFullPath(fileName);
                string targetPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\..\\..\\temp\\" + onlyFileName;

                //----------------------------------------------------------------------------------
                // WCZYTANIE ZAWARTOŚCI PLIKU
                // KOPIA WCZYTANEGO PLIKU DO FOLDERU TEMP


                System.IO.File.Copy(fileName, targetPath, true);

                //USUNIĘCIE PIERWSZEGO WIERSZA I ZAPISANIE KOPII PLIKÓW ŹRÓDŁOWYCH
                File.WriteAllLines(targetPath, File.ReadAllLines(targetPath).Skip(1));


                this.label2.Text = "liczba wierszy: " + File.ReadAllLines(pathOfFile).Length.ToString();
                this.label1.Text = targetPath;



            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            MessageBox.Show("KROK 1: PRZETWARZANIE PLIKÓW");

            //1. wczytanie danych do tablicy file1
            string[] file1BeforeConversion = File.ReadAllLines(label11.Text);
            //2. wczytanie danych do tablicy file2 
            string[] file2BeforeConversion = File.ReadAllLines(label1.Text);
            //3. tablica tymczasowa

            List<string> linesConverted = new List<string>();

            NameValueCollection csvCollection1 = new NameValueCollection();
            NameValueCollection csvCollection2 = new NameValueCollection();


            int lineNumber = 1;
            int linesNumber = file1BeforeConversion.Count() + file2BeforeConversion.Count();

            progressBar1.Value = 1;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;


            foreach (string line in file1BeforeConversion)
            {
                var split = line.Split(';');
                string itemNumberAndSize = split[0];
                string newLine = line.Substring(itemNumberAndSize.Length + 1, line.Length - itemNumberAndSize.Length - 1);
                var lineConverted = itemNumberAndSize + ";" + newLine;

                
                csvCollection1.Add(itemNumberAndSize, ";" + newLine);
                lineNumber = lineNumber + 1;
                label4.Text = "przetwarzany wiersz nr: " + lineNumber;
                progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
            }

            label4.Text = "ZAKOŃCZONO PRZETWARZANIE PLIKU NR 1";

            MessageBox.Show("OK");


        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            MessageBox.Show("WCZYTANIE PLIKU");


            string[] file1BeforeConversion = File.ReadAllLines(label11.Text);

            int lineNumber = 1;
            int linesNumber = file1BeforeConversion.Count();

            progressBar1.Value = 1;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;

            dataGridView1.ColumnCount = 3;

            dataGridView1.Columns[0].Name = "lp";

            dataGridView1.Columns[1].Name = "itemId";

            dataGridView1.Columns[2].Name = "text";


            foreach (string line in file1BeforeConversion)
            {
                var split = line.Split(';');
                string itemNumberAndSize = split[0];
                string newLine = line.Substring(itemNumberAndSize.Length + 1, line.Length - itemNumberAndSize.Length - 1);

                dataGridView1.Rows.Add(lineNumber, itemNumberAndSize, newLine);


                lineNumber = lineNumber + 1;
                label4.Text = "przetwarzany wiersz nr: " + lineNumber;
                progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
            }

            label4.Text = "ZAKOŃCZONO PRZETWARZANIE PLIKU NR 1";

            MessageBox.Show("OK");




        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("KRZYŻOWANIE TABELI");
            string[] file2BeforeConversion = File.ReadAllLines(label1.Text);


            int lineNumber = 1;
            int linesNumber = file2BeforeConversion.Count();

            progressBar1.Value = 1;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;

            

            foreach (string line in file2BeforeConversion)
            {
                var split = line.Split(';');
                string itemNumberAndSize = split[0];
                string newLine = line.Substring(itemNumberAndSize.Length + 1, line.Length - itemNumberAndSize.Length - 1);


                 // DataGridViewRow row = dataGridView1.Rows
                 //     .Cast()
                 //     .Where(r => r.Cells["itemId"].Value.ToString().Equals(itemNumberAndSize))
                 //     .First();



                lineNumber = lineNumber + 1;
                label4.Text = "przetwarzany wiersz nr: " + lineNumber;
                progressBar1.Value = (int)(100 * (lineNumber / linesNumber));
            }

            label4.Text = "ZAKOŃCZONO PRZETWARZANIE PLIKU NR 2";

            MessageBox.Show("OK");

        }
    }
}
